declare module 'web3';
declare module 'truffle-contract';